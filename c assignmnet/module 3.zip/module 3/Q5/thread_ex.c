#include <stdio.h>
#include <pthread.h>
#include <unistd.h>

void* print_hello(void* arg) {
    printf("Hello\n");
    return NULL;
}

void* print_world(void* arg) {
    printf("World\n");
    return NULL;
}

int main() {
    pthread_t t1, t2;

    pthread_create(&t1, NULL, print_hello, NULL);
    pthread_join(t1, NULL);

    pthread_create(&t2, NULL, print_world, NULL);
    pthread_join(t2, NULL);

    return 0;
}
