#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>

#define PORT 8000
#define BUFFER_SIZE 1024

int main() {
    int sock_fd;
    struct sockaddr_in server_addr;
    char buffer[BUFFER_SIZE];
    char input_str[BUFFER_SIZE];

    // Create socket
    sock_fd = socket(AF_INET, SOCK_STREAM, 0);
    if (sock_fd < 0) {
        perror("Socket creation failed");
        exit(EXIT_FAILURE);
    }

    // Setup server address
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(PORT);
    inet_pton(AF_INET, "127.0.0.1", &server_addr.sin_addr);

    // Connect to server
    if (connect(sock_fd, (struct sockaddr *)&server_addr, sizeof(server_addr)) < 0) {
        perror("Connection to server failed");
        exit(EXIT_FAILURE);
    }

    // Get input from user
    printf("Enter a string: ");
    fgets(input_str, BUFFER_SIZE, stdin);
    input_str[strcspn(input_str, "\n")] = 0;  // Remove newline

    // Send to server
    send(sock_fd, input_str, strlen(input_str), 0);

    // Receive result from server
    memset(buffer, 0, BUFFER_SIZE);
    read(sock_fd, buffer, BUFFER_SIZE);
    printf("Server Response: %s\n", buffer);

    // Close socket
    close(sock_fd);

    return 0;
}
