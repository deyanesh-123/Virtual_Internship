#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>

#define PORT 8000
#define MAX_BUF 1024

int main() {
    int socket_fd, conn_fd;
    struct sockaddr_in host_addr, remote_addr;
    char msg_buf[MAX_BUF];

    // Step 1: Create a TCP socket
    socket_fd = socket(AF_INET, SOCK_STREAM, 0);
    if (socket_fd < 0) {
        perror("Unable to create socket");
        return -1;
    }

    // Step 2: Define server address details
    host_addr.sin_family = AF_INET;
    host_addr.sin_addr.s_addr = INADDR_ANY;
    host_addr.sin_port = htons(PORT);

    // Step 3: Attach socket to IP/port
    if (bind(socket_fd, (struct sockaddr *)&host_addr, sizeof(host_addr)) < 0) {
        perror("Binding failed");
        return -1;
    }

    // Step 4: Start listening for incoming connections
    listen(socket_fd, 5);
    printf("Waiting for client on port %d...\n", PORT);

    socklen_t addr_size = sizeof(remote_addr);
    conn_fd = accept(socket_fd, (struct sockaddr *)&remote_addr, &addr_size);
    if (conn_fd < 0) {
        perror("Connection acceptance failed");
        return -1;
    }

    // Step 5: Read incoming data
    read(conn_fd, msg_buf, MAX_BUF);
    printf("Message from client: %s\n", msg_buf);

    // Step 6: Respond to client
    char *reply = "Greetings from Server!";
    write(conn_fd, reply, strlen(reply));

    // Step 7: Close both sockets
    close(conn_fd);
    close(socket_fd);

    return 0;
}
