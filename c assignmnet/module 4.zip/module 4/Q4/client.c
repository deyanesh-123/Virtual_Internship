#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>

#define PORT 8000
#define MAX_DATA 1024

int main() {
    int client_sock;
    struct sockaddr_in target_addr;
    char data_buf[MAX_DATA];

    // Step 1: Initialize TCP socket
    client_sock = socket(AF_INET, SOCK_STREAM, 0);
    if (client_sock < 0) {
        perror("Failed to open socket");
        return -1;
    }

    // Step 2: Define the server's connection parameters
    target_addr.sin_family = AF_INET;
    target_addr.sin_port = htons(PORT);
    inet_pton(AF_INET, "127.0.0.1", &target_addr.sin_addr);

    // Step 3: Attempt to connect to the server
    if (connect(client_sock, (struct sockaddr *)&target_addr, sizeof(target_addr)) < 0) {
        perror("Unable to connect to server");
        return -1;
    }

    // Step 4: Transmit a message
    char *text = "Hello";
    send(client_sock, text, strlen(text), 0);

    // Step 5: Wait for and print server response
    read(client_sock, data_buf, MAX_DATA);
    printf("Server replied: %s\n", data_buf);

    // Step 6: Terminate the session
    close(client_sock);

    return 0;
}
